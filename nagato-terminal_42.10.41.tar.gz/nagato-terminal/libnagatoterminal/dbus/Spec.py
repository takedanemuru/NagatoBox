
Service = "box.nagato.terminal"
ObjectPath = "/box/nagato/terminal"
Interface = "box.nagato.terminal"
