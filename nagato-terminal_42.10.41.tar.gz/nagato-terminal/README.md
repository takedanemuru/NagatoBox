# nagato-terminal

a multi grid terminal emulator with meaningless features.

![image: screenshot_003](./readme_extra/screenshot_003.png)

this software is now under heavy construction.