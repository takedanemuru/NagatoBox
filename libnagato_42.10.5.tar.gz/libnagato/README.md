# libnagato

an application framework.

## modules

libnagato
libnagato/**Object**
libnagato/**Widget**
libnagato/gdk/**X11window**
