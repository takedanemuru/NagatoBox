TEMPLATE = "TEMPLATE"

QUIT = \
    "<span size='large'><u>WARNING !!</u></span>\n"\
    "\n"\
    "Do you really want to close nagato-text ?\n"\
    "\n"

NOT_SAVED = \
    "<span size='large'><u>YOUR CHANGES ARE NOT SAVED !!</u></span>\n"\
    "\n"\
    "If you select Discard,\n"\
    "All your changes will be lost.\n"
