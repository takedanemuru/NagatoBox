# Object Tree of nagato-notebook

+ nagato-notebook
    + NagatoWindow
        + NagatoGrid
            + NagatoBoxToolbar
            + NagatoNotebook
                + NagatoSourceView *n
                    + NagatoTabPanel