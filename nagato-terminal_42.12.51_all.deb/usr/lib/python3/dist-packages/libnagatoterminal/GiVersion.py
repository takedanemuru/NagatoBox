
import gi

gi.require_version("Vte", "2.91")
gi.require_version('Gtk', '3.0')


def require():
    pass
