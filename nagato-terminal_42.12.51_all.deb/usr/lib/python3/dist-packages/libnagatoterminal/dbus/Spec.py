
Service = "io.github.takedanemuru.nagato-terminal"
ObjectPath = "/box/nagato/terminal"
Interface = "box.nagato.terminal"
